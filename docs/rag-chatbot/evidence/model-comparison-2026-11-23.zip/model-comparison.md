| Date | Label | Model | Retrieval hit | Answer acc | Unanswerable clean | Off-topic refusal | TTFT | Total | Notes |
|---|---|---|---|---|---|---|---|---|---|
| 2026-11-23 | Qwen/Qwen3-8B (bf16, Colab NVIDIA L4) | Qwen/Qwen3-8B | 100% | 95% | 83% | 100% | 0.4 s | 3.5 s | top_k=4, min_score=0.5, keyword_weight=0.2, prefix=on |
| 2026-11-23 | Qwen/Qwen2.5-7B-Instruct (bf16, Colab NVIDIA L4) | Qwen/Qwen2.5-7B-Instruct | 100% | 95% | 100% | 80% | 0.4 s | 2.6 s | top_k=4, min_score=0.5, keyword_weight=0.2, prefix=on |
| 2026-11-23 | Qwen/Qwen3-4B-Instruct-2507 (bf16, Colab NVIDIA L4) | Qwen/Qwen3-4B-Instruct-2507 | 100% | 95% | 100% | 100% | 0.3 s | 3.2 s | top_k=4, min_score=0.5, keyword_weight=0.2, prefix=on |
| 2026-11-23 | ibm-granite/granite-3.3-8b-instruct (bf16, Colab NVIDIA L4) | ibm-granite/granite-3.3-8b-instruct | 100% | 95% | 0% | 40% | 0.5 s | 3.2 s | top_k=4, min_score=0.5, keyword_weight=0.2, prefix=on |
